package com.example.updateinventory;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UpdateInventoryApplication {

    public static void main(String[] args) {
        SpringApplication.run(UpdateInventoryApplication.class, args);
    }

}
