package com.example.updateinventory;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UpdateInventoryApplicationTests {

    @Test
    void contextLoads() {
    }

}
